const express = require("express")
const client =require('./Connection')
// var cors = require('cors')
const bodyParser = require("body-parser");
 


// app.use(cors());
var app=express()
app.use(bodyParser.json());



 client.connect();


//  app.get("/", (req, res) => {
//     res.send("index.html");
//   });



   app.get('/getDetails',(req,res)=>{
    try {
        console.log("innn")
        client.query("select * from new_student",(err,result)=>{            
        if(!err){
            res.send(result.rows);
            console.log(result.rows)
        }
    });
    } catch (error) {
        console.log(error,"error")
    }
    client.end;
})










app.post('/addStudent',(req,res)=>{
    let insert = `insert into new_student (name,fathername,village,course,coursecategory,studentcategory,studentnumber,
        parentnumber,joindate) values 
    ('${req.body.name}' , '${req.body.fathername}', '${req.body.village}', '${req.body.course}', '${req.body.coursecategory}', 
    '${req.body.studentcategory}', ${req.body.studentnumber}, ${req.body.parentnumber}, ${req.body.joindate})`
    client.query(insert,(err,result)=>{
        if(!err){
            res.send("Insertion success");
        }else{
            console.log(err.message);
        }
    })
})















app.listen(5000, function() {
    console.log("application successfully runnning on port 5000")
 })





